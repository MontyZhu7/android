// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services','ngIOS9UIWebViewPatch'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleLightContent();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {

  $ionicConfigProvider.platform.android.tabs.style('standard');
  $ionicConfigProvider.platform.android.tabs.position('bottom');
  $ionicConfigProvider.platform.android.navBar.alignTitle('center');
  $ionicConfigProvider.backButton.previousTitleText(false).text('');

  $stateProvider

  .state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'templates/tabs.html'
  })

  .state('tab.game', {
    url: '/game',
    views: {
      'tab-game': {
        templateUrl: 'templates/tab-game.html',
        controller: 'GameCtrl'
      }
    }
  })

  .state('tab.forums', {
    url: '/forums/:fid/:defaultFid',
    views: {
      'tab-game': {
        templateUrl: 'templates/tab-forums.html',
        controller: 'ForumsCtrl'
      }
    }
  })

    .state('tab.forum-post', {
      url: '/post',
      views: {
        'tab-game': {
          templateUrl: 'templates/forum-post.html',
          controller: 'PostCtrl'
        }
      }
    })

    .state('tab.forum-reply', {
      url: '/reply',
      views: {
        'tab-game': {
          templateUrl: 'templates/forum-reply.html',
          controller: 'ReplyCtrl'
        }
      }
    })

    .state('tab.communicateFid', {
      url: '/communicateFid',
      views: {
        'tab-forums': {
          templateUrl: 'templates/tab-forums.html'
        }
      }
    })

    .state('tab.noticeFid', {
      url: '/noticeFid',
      views: {
        'tab-forums': {
          templateUrl: 'templates/tab-forums.html'

        }
      }
    })

    .state('tab.battleFid', {
      url: '/battleFid',
      views: {
        'tab-forums': {
          templateUrl: 'templates/tab-forums.html'
       }
      }
    })

    .state('tab.customerFid', {
      url: '/customerFid',
      views: {
        'tab-forums': {
          templateUrl: 'templates/tab-forums.html'
       }
      }
    })

  .state('tab.forum-detail', {
    url: '/forum-detail/:tid',
    views: {
      'tab-game': {
        templateUrl: 'templates/forum-detail.html',
        controller: 'ThreadCtrl'
      }
    }
  })

  .state('tab.personal', {
    url: '/personal',
    cache: false,
    views: {
      'tab-personal': {
        templateUrl: 'templates/tab-personal.html',
        controller: 'PersonalCtrl'
      }
    }
  })

//  .state('tab.login', {
//    url: '/login',
//    cache: false,
//    views: {
//      'tab-login': {
//        templateUrl: 'templates/tab-login.html',
//        controller: 'LoginCtrl'
//      }
//    }
//  })
//
//  .state('tab.regist', {
//    url: '/regist',
//    cache: false,
//    views: {
//      'tab-regist': {
//        templateUrl: 'templates/tab-regist.html',
//        controller: 'RegistCtrl'
//      }
//    }
//  })

    .state('tab.contract', {
      url: '/contract',
      views: {
        'tab-personal': {
          templateUrl: 'templates/contract.html'
        }
      }
    })

  .state('tab.social', {
    url: '/social',
    cache: false,
    views: {
      'tab-social': {
        templateUrl: 'templates/tab-social.html',
        controller: 'SocialCtrl'
      }
    }
  })

    .state('tab.friends', {
      url: '/friends',
      views: {
        'tab-social': {
          templateUrl: 'templates/tab-social.html'
        }
      }
    })

    .state('tab.chat', {
      url: '/chat',
      views: {
        'tab-social': {
          templateUrl: 'templates/tab-social.html'

        }
      }
    })

    .state('tab.sysNotice', {
      url: '/sysNotice',
      views: {
        'tab-social': {
          templateUrl: 'templates/tab-social.html'
       }
      }
    })

  .state('tab.set', {
    url: '/set',
    cache: false,
    views: {
      'tab-set': {
        templateUrl: 'templates/tab-set.html',
        controller: 'SetCtrl'
      }
    }
  });

  $urlRouterProvider.otherwise('/tab/game');

});

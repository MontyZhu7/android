angular.module('starter.controllers', ['ionic','ui.router', 'ui.validate', 'monospaced.elastic'])

.filter('unsafe', function($sce) {

  return $sce.trustAsHtml;
})

// .directive('hideTabs', function($rootScope) {
//   return {
//     restrict: 'A',
//     link: function(scope, element, attributes) {
//       scope.$watch(attributes.hideTabs, function(value) {
//         $rootScope.hideTabs = value;
//       });
//       scope.$on('$destroy', function() {
//         $rootScope.hideTabs = false;
//       });
//     }
//   };
// })

.directive('hideTabs', function($rootScope) {
  return {
    restrict: 'A',
    link: function(scope, element, attributes) {
      scope.$on('$ionicView.beforeEnter', function() {
        scope.$watch(attributes.hideTabs, function(value) {
          $rootScope.hideTabs = value;
        });
      });
      scope.$on('$ionicView.beforeLeave', function() {
        $rootScope.hideTabs = false;
      });
    }
  };
})

.directive('focusMe', function($timeout) {
  return {
    link: function(scope, element, attrs) {
      $timeout(function() {
        element[0].focus();
        if (ionic.Platform.isAndroid()) {
          cordova.plugins.Keyboard.show();
        }
      }, 150);
    }
  };
})

.run(['$window', '$rootScope', function($window, $rootScope) {
  $rootScope.goBack = function() {
    $window.history.back();
  }
}])

.controller('GameCtrl', function($scope, $rootScope, $http, GameService, CommonService) {
  var game = {
    url: CommonService.RootURL + 'index.htm?callback=JSON_CALLBACK&type=',
    pc: ['pc', 0],
    mobile: ['mobile', 1]
  };
  //
  $http.jsonp(game.url + game.pc[1])
    .then(function(response) {
      GameService.set(game.pc[0], response.data);
      $scope.pcGames = GameService.get(game.pc[0]);
      $rootScope.islogin = response.data.isLogin;
    })
    .then(function() {
      $http.jsonp(game.url + game.mobile[1])
        .success(function(response) {
          GameService.set(game.mobile[0], response);
          $scope.mGames = GameService.get(game.mobile[0]);
        })
    });
})

.controller('ForumsCtrl', function($scope, $http, $stateParams, $rootScope, $q, ForumsService, CommonService) {
  $scope.forum = {
    fid: $stateParams.fid,
    otherSubFidsUrl: function() {
      return CommonService.RootURL + 'subIndex.htm?callback=JSON_CALLBACK&fid=' + this.fid
    },
    curSubFid: $stateParams.defaultFid,
    curSubFidUrl: function() {
      return CommonService.RootURL + 'listThreads.htm?callback=JSON_CALLBACK&fid=' + this.curSubFid + '&page='
    },
    firstPage: 1,
    communicateFidPages: 1,
    noticeFidPages: 2,
    battleFidPages: 2,
    customerFidPages: 2,
    moreCommunicate: true,
    moreNotice: true,
    moreBattle: true,
    moreCustomer: true
  };
  $rootScope.communicates = [];
  $rootScope.notices = [];
  $rootScope.battles = [];
  $rootScope.customers = [];
  //
  $http.jsonp($scope.forum.otherSubFidsUrl())
    .then(function(response) {
      ForumsService.set($http, response.data);
      ForumsService.curFid = $scope.forum.curSubFid;
      //***//
      $scope.onTabSelected = function(args) {
        console.log(ForumsService.fids[args]);
        if (!angular.equals({}, ForumsService.fids)) {
          $scope.forum.curSubFid = ForumsService.fids[args];

          ForumsService.curFid = ForumsService.fids[args];
          ForumsService.curFidName = args;
        }
      }
    })
    .then(function() {
      $q.all(ForumsService.fidsLink)
        .then(function(response) {
          ForumsService.setItems(response);
          $scope.isBattle = ForumsService.isBattle;
          $rootScope.communicates = ForumsService.fidsItem['communicateFid'];
          $rootScope.notices = ForumsService.fidsItem['noticeFid'];
          $rootScope.battles = ForumsService.fidsItem['battleFid'];
          $rootScope.customers = ForumsService.fidsItem['customerFid'];
        })
    })
    //下拉刷新
  $scope.doRefresh = function(args) {
    $http.jsonp($scope.forum.curSubFidUrl() + $scope.forum.firstPage)
      .success(function(response) {
        ForumsService.setItems(response);
        try {
          if (!angular.equals({}, ForumsService.fids)) {
            switch (args) {
              case 'communicateFid':
                $rootScope.communicates = ForumsService.fidsItem[args];
                break;
              case 'noticeFid':
                $rootScope.notices = ForumsService.fidsItem[args];
                break;
              case 'battleFid':
                $rootScope.battles = ForumsService.fidsItem[args];
                break;
              case 'customerFid':
                $rootScope.customers = ForumsService.fidsItem[args];
                break;
            }
          }
        } catch (err) {
          console.log(err);
        }
        $scope.forum[args + 'Pages'] = $scope.forum.firstPage + 1;
      })
      .finally(function() {
        $scope.$broadcast('scroll.refreshComplete');
      });
  };
  //上拉追加
  $scope.loadMore = function(args) {
    $http.jsonp($scope.forum.curSubFidUrl() + $scope.forum[args + 'Pages'])
      .success(function(response) {
        if (!($scope.forum[args + 'Pages'] < response.pages)) {
          switch (args) {
            case 'communicateFid':
              $scope.moreCommunicate = false;
              break;
            case 'noticeFid':
              $scope.moreNotice = false;
              break;
            case 'battleFid':
              $scope.moreBattle = false;
              break;
            case 'customerFid':
              $scope.moreCustomer = false;
              break;
          }
        }
        ForumsService.setItems(response);
        try {
          if (!angular.equals({}, ForumsService.fids)) {
            switch (args) {
              case 'communicateFid':
                $rootScope.communicates = $rootScope.communicates.concat(ForumsService.fidsItem[args]);
                break;
              case 'noticeFid':
                $rootScope.notices = $rootScope.notices.concat(ForumsService.fidsItem[args]);
                break;
              case 'battleFid':
                $rootScope.battles = $rootScope.battles.concat(ForumsService.fidsItem[args]);
                break;
              case 'customerFid':
                $rootScope.customers = $rootScope.customers.concat(ForumsService.fidsItem[args]);
                break;
            }
          }
        } catch (err) {
          console.log(err);
        }
        $scope.$broadcast('scroll.infiniteScrollComplete');
        $scope.forum[args + 'Pages'] += 1;
      });
  }
})

.controller('PostCtrl', function($scope, $http, $ionicPopup, $rootScope, $ionicHistory, ForumsService, CommonService) {
  try {
    $http.jsonp(CommonService.RootURL + 'getSubjectTypes.htm?callback=JSON_CALLBACK&fid=' + ForumsService.curFid)
      .success(function(response) {
        $scope.subjectTypes = response.threadClass;
        $scope.forums = {
          "subjectId": $scope.subjectTypes[0]
        }
      })
  } catch (err) {
    console.log(err);
  }
  $scope.cancel = function() {
    $ionicHistory.goBack();
  }
  $scope.submitForums = function(forums) {
    try {
      $http.jsonp(CommonService.RootURL + 'postMobile.htm?callback=JSON_CALLBACK', {
        params: {
          fid: forums.subjectId.fid,
          theme: forums.theme,
          subjectId: forums.subjectId.id,
          content: forums.content
        }
      }).success(function(response) {
        if (response.state) {
          $ionicHistory.goBack();
          var newItem = response.thread[0];
          try {
            switch (ForumsService.curFidName) {
              case 'communicateFid':
                $rootScope.communicates.unshift(newItem);
                break;
              case 'noticeFid':
                $rootScope.notices.unshift(newItem);
                break;
              case 'battleFid':
                $rootScope.battles.unshift(newItem);
                break;
              case 'customerFid':
                $rootScope.customers.unshift(newItem);
                break;
            }
          } catch (err) {
            console.log(err);
          }
        } else {
          CommonService.showAlert($ionicPopup, response);
        }
      })
    } catch (err) {
      console.log(err);
    }
  }
})

.controller('ThreadCtrl', function($scope, $rootScope, $http, $ionicPopup, $stateParams, $ionicActionSheet, $state, ThreadService, CommonService) {
  var thread = {
    url: CommonService.RootURL + 'getThreadInfo.htm?callback=JSON_CALLBACK&tid=' + $stateParams.tid + '&page=',
    firstPage: 1,
    currentPage: 1
  };
  $scope.moreThreadLoaded = true;
  $scope.owner = [];
  $rootScope.replys = [];
  $scope.doRefresh = function() {
    $http.jsonp(thread.url + thread.firstPage)
      .success(function(response) {
        ThreadService.set(response);
        $scope.owner = ThreadService.get('first');
        $rootScope.replys = ThreadService.get('replyThreads');
        thread.currentPage = thread.firstPage + 1;
      })
      .finally(function() {
        $scope.$broadcast('scroll.refreshComplete');
      });
  };
  $scope.loadMoreData = function() {
    $http.jsonp(thread.url + thread.currentPage)
      .success(function(response) {
        ThreadService.set(response);
        if (!(thread.currentPage < ThreadService.get('pages'))) {
          $scope.moreThreadLoaded = false;
        }
        if (ThreadService.thread.hasOwnProperty('first')) {
          $scope.owner = ThreadService.get('first');
        }
        $rootScope.replys = ThreadService.get('replyThreads');
        $scope.$broadcast('scroll.infiniteScrollComplete');
        thread.currentPage += 1;
      })
  };

  $scope.showReplys = function(author, floor) {
    ThreadService.thread.quoteReply = author;
    ThreadService.thread.qutoeReplyFloor = floor;
    var hideSheet = $ionicActionSheet.show({
      buttons: [{
        text: '回复'
      }, {
        text: '收藏'
      }, {
        text: '举报'
      }],
      cancelText: '取消',
      cancel: function() {
        // add cancel code..
      },
      buttonClicked: function(index) {
        /**
         * 0-回复
         * 1-收藏
         * 2-举报
         */
        if (index == 0) {
          $state.go('tab.forum-reply');
        } else if (index == 1) {
          $http.jsonp(CommonService.RootURL + 'mobileCollect.htm?callback=JSON_CALLBACK', {
            params: {
              tid: ThreadService.get('first')[0]['tid']
            }
          }).success(function(response) {
            CommonService.showAlert($ionicPopup, response);
          });
          return true;
        } else if (index == 2) {
          ThreadService.showConfirm($ionicPopup);
          return true;
        }
      }
    });
  };
})

.controller('ReplyCtrl', function($scope, $rootScope, $http, $ionicPopup, $ionicHistory, ThreadService, CommonService) {
  $scope.reply = function(forums) {
    try {
      var content;
      if (ThreadService.thread.quoteReply == 'quote') {
        var quoteReplyFloor = ThreadService.get('replyThreads')[ThreadService.get('qutoeReplyFloor')];
        var quoteContent = (quoteReplyFloor['author'] + '发表于' +
          quoteReplyFloor['postDate']).replace(/\n|\r/g, '');
        if (quoteReplyFloor['content'].toString().length > 25) {
          quoteReplyFloor['content'] = quoteReplyFloor['content'].substring(0, 24);
          quoteReplyFloor['content'] += '...';
        }
        quoteContent += quoteReplyFloor['content'];
        content = '[quote]' + quoteContent + '[/quote]' + forums.content;
      } else {
        content = forums.content;
      }
      $http.jsonp(CommonService.RootURL + 'replyThread.htm?callback=JSON_CALLBACK', {
        params: {
          tid: ThreadService.get('first')[0]['tid'],
          content: content
        }
      }).success(function(response) {
        if (response.state) {
          $ionicHistory.goBack();
          var newItem = response.replyThreads[0];
          $rootScope.replys.push(newItem);
        } else {
          CommonService.showAlert($ionicPopup, response);
        }
      })
    } catch (err) {
      console.log(err);
    }
  }
  $scope.cancel = function() {
    $ionicHistory.goBack();
  }
})

.controller('PersonalCtrl', function($scope, $rootScope, $http, CommonService, ModalService) {
  console.log(0);
  try {
    $http.jsonp(CommonService.RootURL + 'center-user-info.htm?callback=JSON_CALLBACK')
      .then(function(response) {
        $rootScope.islogin = response.data.state;
        $scope.userInfo = response.data;
      })
      .then(function() {
        $http.jsonp(CommonService.RootURL + 'center.htm?callback=JSON_CALLBACK')
          .success(function(response) {
            //            $scope.myThreads = response.myThreads.titles;
            //            $scope.myCollections = response.myCollections.titles;
            //            $scope.myRoles = response.myRoles;
          })
      })
    //
    if (!$rootScope.islogin) {
      ModalService.init('templates/tab-login.html', $scope).then(function (modal) {
          modal.show();
      });
    }
  } catch (err) {
    console.log(err);
  }
})

.controller('LoginCtrl', function($scope,$rootScope,$http,$state, $ionicPopup, CommonService,ModalService) {
 try {
   $scope.login = function(user) {
     $scope.userParams = 'username=' + user.name + '&password=' + user.password + '&command=login';
     $http.jsonp(CommonService.RootURL + 'mb-user.htm?callback=JSON_CALLBACK', {
       params: {
         token: encryptedString(CommonService.RSAKey(), encodeURIComponent($scope.userParams))
       }
     }).success(function(response) {
       if (response.state) {
          $rootScope.islogin = true;
          $scope.closeModal('true');
       } else {
         CommonService.showAlert($ionicPopup, response);
       }
     })
   }
   $scope.openRegistModal = function(){
    $scope.closeModal();
    // if (ionic.Platform.isAndroid()) {
    //   cordova.plugins.Keyboard.close();
    // }
    ModalService.init('templates/tab-regist.html', $scope).then(function (modal) {
      modal.show();
    });
   }
 } catch (err) {
   console.log(err);
 }
})

.controller('RegistCtrl', function($scope,$rootScope, $http, $state, $ionicPopup, RegistService, CommonService) {
  $scope.user = {
    'name': '',
    'password': '',
    'validate': '',
  };
  $scope.userExist = true;
  $scope.validateUrl = CommonService.validateUrl;
  $scope.validate = function() {
    CommonService.setAttr(CommonService.validateID);
    RegistService.emptyValidate($scope);
  };
  $scope.checkName = function(user) {
    try {
      if (user != '' && user != undefined && RegistService.checkName(user)) {
        $http.jsonp(CommonService.RootURL + 'mb-userExist.htm?callback=JSON_CALLBACK', {
          params: {
            username: user
          }
        }).success(function(response) {
          $scope.errorName = response.message;
          $scope.userExist = response.state;
        })
      }
    } catch (err) {
      console.log(err)
    }
  }
  $scope.regist = function(user) {
    try {
      $scope.registArgs = 'username=' + user.name + '&password=' + user.password + '&validationCode=' + user.validate + '&command=regist';
      $http.jsonp(CommonService.RootURL + 'mb-user.htm?callback=JSON_CALLBACK', {
        params: {
          token: encryptedString(CommonService.RSAKey(), encodeURIComponent($scope.registArgs))
        }
      }).success(function(response) {
        if (response.state) {
          $rootScope.islogin = true;
          $scope.closeModal('true');
        } else {
          CommonService.showAlert($ionicPopup, response);
          RegistService.emptyValidate($scope);
        }
      })
    } catch (err) {
      console.log(err);
    }
  }
})

.controller('SocialCtrl', function($scope, $rootScope, $state, ModalService) {
  console.log('social');
  if (!$rootScope.islogin) {
    ModalService.init('templates/tab-login.html', $scope).then(function (modal) {
      modal.show();
    });
  }
})

.controller('SetCtrl', function($scope, $rootScope, $state, $http, CommonService,ModalService) {
  console.log(2);
  try {
    $scope.logout = function() {
        $http.jsonp(CommonService.RootURL + 'mb-logout.htm?callback=JSON_CALLBACK')
          .success(function(response) {
            $rootScope.islogin = false;
            $state.go('tab.game');
          })
      }
    if (!$rootScope.islogin) {
      ModalService.init('templates/tab-login.html', $scope).then(function (modal) {
        modal.show();
      });
    }
  } catch (err) {
    console.log(err);
  }
});

angular.module('starter.services', [])

.factory('CommonService', function() {
  return {
    // RootURL: 'http://testbbs.aoshitang.com/',
    // validateUrl: "http://testbbs.aoshitang.com/validation-code.action?x=" + Math.random(),
   RootURL: 'http://bbs.aoshitang.com/',
   validateUrl: "http://bbs.aoshitang.com/validation-code.action?x=" + Math.random(),
    validateID: 'validate',
    RSAKey: function() {
      /**
       * 此加密参数（exp,mod）及方式为后端提供
       * exp "010001"
       * mod "00811afd62865440da2d4c581930624130905d3126d6202c1933ad39c26826e21afb3cbdf0cdff2b6f52d308a2c1a6942dcfd0bbeed6f6c9ff3702ae5fc5dfc82bead94cb511001766e944d4bb63e7d92f257ab5ced5ed0d748d031a80cd0294a695af92c5fd1ab3ee39dce96c88e795174528549ada58a03e6748788fa1744407"
       *
       */
      setMaxDigits(130);
      return new RSAKeyPair("010001", "", "00811afd62865440da2d4c581930624130905d3126d6202c1933ad39c26826e21afb3cbdf0cdff2b6f52d308a2c1a6942dcfd0bbeed6f6c9ff3702ae5fc5dfc82bead94cb511001766e944d4bb63e7d92f257ab5ced5ed0d748d031a80cd0294a695af92c5fd1ab3ee39dce96c88e795174528549ada58a03e6748788fa1744407");
    },
    showAlert: function($ionicPopup, response) {
      var _this = this;
      var alertPopup = $ionicPopup.alert({
        title: '异常',
        template: response.message
      });
      alertPopup.then(function(response) {
        if (!response.state) {
          _this.setAttr(_this.validateID);
        }
      });
    },
    showPopup: function($ionicPopup, $timeout, response) {
      var myPopup = $ionicPopup.show({
        title: '异常',
        template: response.message,
      });
      $timeout(function() {
        myPopup.close();
      }, 3000);
    },
    setAttr: function(id) {

      angular.element(document.querySelector('#' + id)).attr('src', this.validateUrl);
    }
  };
})

.factory('ModalService', function($ionicModal, $rootScope, $http, $state) {
  var init = function(tpl, $scope) {
    var promise;
    $scope = $scope || $rootScope.$new();
    promise = $ionicModal.fromTemplateUrl(tpl, {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function(modal) {
      $scope.modal = modal;
      return modal;
    });
    $scope.openModal = function() {
      $scope.modal.show();
    };
    $scope.closeModal = function(reloadState) {
      if (ionic.Platform.isAndroid()) {
        cordova.plugins.Keyboard.close();
      }
      $scope.modal.hide();
      reloadState ? $state.reload() : '';
    };
    $scope.$on('$destroy', function() {
      $scope.modal.remove();
    });
    return promise;
  };
  return { init: init };
})

.factory('GameService', function() {
  return {
    game: {},
    set: function(key, value) {
      this.game[key] = value.games
    },
    get: function(key) {
      return this.game[key];
    }
  }
})

.factory('ForumsService', function() {
  return {
    fids: {},
    fidsLink: [],
    fidsItem: {},
    curFid: '',
    curFidName: 'communicateFid', //默认设置为“交流”版块
    isBattle: false,
    set: function($http, result) {
      this.isBattle = result.forums[0]['battleFid'] === null ? false : true;
      for (var name in result.forums[0]) {
        if (!(result.forums[0][name] == null)) {
          if (name.indexOf("Fid") > -1) {
            this.fids[name] = result.forums[0][name];
          } else if (name.indexOf("Link") > -1) {
            if (!(name.indexOf('communicateLink') > -1) && !(result.forums[0][name] == null)) {
              var link = result.forums[0][name].split('?');
              this.fidsLink = this.fidsLink.concat($http.jsonp(link[0] + '?callback=JSON_CALLBACK&' + link[1]));
            }
          }
        } else {}
      }
    },
    setItems: function(result) {
      if (angular.isArray(result)) {
        for (var i in result) {
          for (var name in this.fids) {
            if (this.fids[name] == result[i].data.threads[(result[i].data.threads.length - 1)].fid) {
              this.fidsItem[name] = result[i].data.threads;
            }
          }
        }
      } else {
        for (var name in this.fids) {
          if (this.fids[name] == result.threads[result.threads.length - 1].fid) {
            this.fidsItem[name] = result.threads;
          }
        }
      }
    }
  };
})

.factory('PostService', function() {




})

.factory('ThreadService', function() {
  return {
    thread: {},
    set: function(result) {
      if(result.isFirst){
        this.thread = result;
      }else{
        this.thread.replyThreads = this.thread.replyThreads.concat(result.replyThreads);
      }
    },
    get: function(key) {
      return this.thread[key];
    },
    showConfirm: function($ionicPopup) {
       var confirmPopup = $ionicPopup.confirm({
         title: '举报该帖子',
         template: '举报此帖子含有不合适的内容，我们的管理人员将在24小时内处理你的请求。',
         cancelText: '取消',
         okText: '确认'
       });
       confirmPopup.then(function(res) {
         if(res) {
           console.log('Yes');
         } else {
           console.log('No');
         }
       });
     }
  }
})

.factory('ReplyService',function(){


})

.factory('PersonalService',function(){


})

.factory('LoginService', function(CommonService,ModalService) {
  // return {
  //   login: function(user) {
  //     $scope.userParams = 'username=' + user.name + '&password=' + user.password + '&command=login';
  //     $http.jsonp(CommonService.RootURL + 'mb-user.htm?callback=JSON_CALLBACK', {
  //       params: {
  //         token: encryptedString(CommonService.RSAKey(), encodeURIComponent($scope.userParams))
  //       }
  //     }).success(function(response) {
  //       if (response.state) {
  //         $rootScope.isLogin = true;
  //         $scope.closeModal();
  //       } else {
  //         CommonService.showAlert($ionicPopup, response);
  //       }
  //     })
  //   }
  // }
})

.factory('RegistService', function() {
  return {
    emptyValidate: function($scope) {
      $scope.user.validate = '';
    },
    checkName: function(name) {
      var RegExp = /^[\u4e00-\u9fa5a-zA-Z0-9_.@]{5,15}$/;
      return RegExp.test(name);
    }
  }
})

.factory('SocialService',function(){


})

.factory('SetService',function(){


})
